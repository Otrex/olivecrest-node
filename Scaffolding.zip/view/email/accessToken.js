module.exports = (data) => `
	<h1> Registration Successful </h1>${JSON.stringify(data)}
	<p> Dear user ${data.user.username} your registeration has been Successful</p>
	<p> Your verification code is: ${data.token} </p>
	<small> &copy; ${data.app_name} </small>
`