

class MailTemplate {
	constructor (template, data) {
		this.template = require('../../view/email/' + template)(data)
	}

	get() {
		return this.template
	}
}

module.exports = MailTemplate