
const mongoose = require('mongoose')
const moment = require('moment')

// The wallet would Store Transactions
// Wallet Schema
const WalletSchema = new mongoose.Schema({ 
	type : {
		type : String
	},
	amount : {
		type : Number
	},
	timestamp : {
		type : Number,
		default : moment().format("X")
	}
}); 

WalletSchema.methods.availableBalance = function(){
	var data = this.where('type', 'credit')
	return data.reduce((total, e )=> {
		return total + e.amount
	}, 0)
}
const Wallet = mongoose.model('Wallet', WalletSchema)

module.exports = Wallet